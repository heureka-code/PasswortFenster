__doc__ = """
class LabelWidget:
    Der Konsruktor nimmt den String text
"""


class LabelWidget:
    def __init__(self, text: str):
        self.text = text
        pass
    pass
