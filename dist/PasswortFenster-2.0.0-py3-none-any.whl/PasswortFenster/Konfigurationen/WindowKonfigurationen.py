__doc__ = """
class WindowKonfiguration:
    Nimmt den String title
"""


class WindowKonfiguration:
    def __init__(self, title: str):
        self.title = title
        pass
    pass
