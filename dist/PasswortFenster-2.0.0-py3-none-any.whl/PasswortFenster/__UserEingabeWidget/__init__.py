from .UserEntry import __doc__ as UserEntry__doc__
from .UserEntry import UserEntry

__annotaions__ = "Beinhaltet die nötigen Module für ein Usernameeingabefeld"
__doc__ = "Usernameeingabe-Widget\n" + UserEntry__doc__
